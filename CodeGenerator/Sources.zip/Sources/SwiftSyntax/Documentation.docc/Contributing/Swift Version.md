# Language Features Usable in swift-syntax

Defines which language features the swift-syntax package can use.

We require that SwiftSyntax builds with the latest released compiler and the previous major version (e.g. with Swift 5.8 and Swift 5.7).

*This documentation article needs to be expanded*
