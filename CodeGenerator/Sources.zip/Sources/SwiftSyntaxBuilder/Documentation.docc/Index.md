# ``SwiftSyntaxBuilder``

SwiftSyntaxBuilder is a tool for generating Swift code in a convenient way using result builders.
